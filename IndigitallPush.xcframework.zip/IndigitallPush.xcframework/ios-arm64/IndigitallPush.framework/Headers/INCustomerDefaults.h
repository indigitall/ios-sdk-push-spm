//
//  INCustomerDefault.h
//  Indigitall
//
//  Created by indigitall on 23/5/22.
//  Copyright © 2022 Indigital. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "INDefaults.h"
NS_ASSUME_NONNULL_BEGIN

@interface INCustomerDefaults : INDefaults


@end

NS_ASSUME_NONNULL_END
