//
//  CustomerValidations.h
//  IndigitallCustomer
//
//  Created by indigitall on 8/3/23.
//

#import <Foundation/Foundation.h>
#import "INValidations.h"
NS_ASSUME_NONNULL_BEGIN

@interface INCustomerValidations : INValidations

@end

NS_ASSUME_NONNULL_END
