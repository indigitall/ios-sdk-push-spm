//
//  INPushButton.h
//  indigitall-objc
//
//  Created by indigitall on 03/09/2019.
//  Copyright © 2019 indigitall. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "INPushAction.h"

NS_ASSUME_NONNULL_BEGIN

@interface INPushButton : NSObject

@property NSString *label;
@property INPushAction *action;
@property NSArray *topics;

-(id)init:(NSDictionary *)json;
- (NSDictionary*)toDictionary;

@end

NS_ASSUME_NONNULL_END
